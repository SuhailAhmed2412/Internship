// Declaraitions
var datetime= document.getElementById("datetime");
var welcome= document.getElementById("welcomenote");
var moveMouse= document.getElementById("move");
var enterMouse= document.getElementById("enter");
var overMouse= document.getElementById("over");
var btnIncrease= document.getElementById("btnIncrease");
var btnDecrease= document.getElementById("btnDecrease");
var increasingText= document.getElementById("increasingtext");
var btn1= document.getElementById("button1");
var btn2= document.getElementById("button2");
var btn3= document.getElementById("button3");
var btn4= document.getElementById("button4");
var btn5= document.getElementById("button5");
var btn6= document.getElementById("button6");
var list= document.getElementById("todo-list");
var inputBox= document.getElementById("inputtext");

// Initializations
var moveCount=0;
var enterCount=0;
var overCount=0;
var increaseFontSize=20;
var CurrntInputText= '';

// Functions

setInterval( function() {
    var initialCount=1;
    initialCount +=1;
    var datentime = new Date();
    var day= datentime.getDay();
    var date= datentime.getDate();
    var month= datentime.getMonth();
    var year= datentime.getFullYear();
    var hours= datentime.getHours();
    var minutes= datentime.getMinutes();
    var seconds= datentime.getSeconds();
    switch (day) {
        case 0 : day='Sunday'; break;
        case 1 : day='Monday'; break;
        case 2 : day='Tuesday'; break;
        case 3 : day='Wednesday'; break;
        case 4 : day='Thursday'; break;
        case 5 : day='Friday'; break;
        case 6 : day='Saturday'; break;
    }
    switch (month) {
        case 0 : month='Jan'; break;
        case 1 : month='Feb'; break;
        case 2 : month='Mar'; break;
        case 3 : month='Apr'; break;
        case 4 : month='May'; break;
        case 5 : month='Jun'; break;
        case 6 : month='Jul'; break;
        case 7 : month='Aug'; break;
        case 8 : month='Sep'; break;
        case 9 : month='Oct'; break;
        case 10 : month='Nov'; break;
        case 11 : month='Dec'; break;
    }
    datetime.textContent= date+"-"+month+"-"+year+" | "+day+" "+hours+":"+minutes+":"+seconds;
},1000);

moveMouse.addEventListener('mousemove' , function() {
    var details= document.getElementById("moveDisplay");
    var countElement= document.getElementById("pmove");
    moveCount += 1;
    countElement.innerHTML= moveCount;
    //moveMouse.style.backgroundColor= "rgb("+Math.floor(Math.random()*255)+","+Math.floor(Math.random()*255)+","+Math.floor(Math.random()*255)+")";
    moveMouse.style.backgroundColor= "#05a859";
    details.innerHTML="Count of Move Mouse Event " + moveCount;
});

moveMouse.addEventListener('mouseleave', function() {
    moveMouse.style.backgroundColor="";
})

enterMouse.addEventListener('mouseenter', function(){
    var details= document.getElementById("enterDisplay");
    var countElement= document.getElementById("penter");
    enterCount += 1;
    countElement.innerHTML= enterCount;
    //enterMouse.style.backgroundColor= "rgb("+Math.floor(Math.random()*255)+","+Math.floor(Math.random()*255)+","+Math.floor(Math.random()*255)+")";
    enterMouse.style.backgroundColor= "#05a859";
    details.innerHTML="Count of Enter Mouse Event " + enterCount;
});

enterMouse.addEventListener('mouseleave', function() {
    enterMouse.style.backgroundColor="";
})

overMouse.addEventListener('mouseover', function(){
    var details= document.getElementById("overDisplay");
    var countElement= document.getElementById("pover");
    overCount += 1;
    countElement.innerHTML= overCount;
    //overMouse.style.backgroundColor= "rgb("+Math.floor(Math.random()*255)+","+Math.floor(Math.random()*255)+","+Math.floor(Math.random()*255)+")";
    overMouse.style.backgroundColor= "#05a859";
    details.innerHTML="Count of Over Mouse Event " + overCount;
});

overMouse.addEventListener('mouseleave', function() {
    overMouse.style.backgroundColor="";
})

btnIncrease.onmouseover= function() {
    btnIncrease.style.backgroundColor="black";
    btnIncrease.style.color="white";
}
btnDecrease.onmouseover= function() {
    btnDecrease.style.backgroundColor="black";
    btnDecrease.style.color="white";
}
btn1.onmouseover= function() {
    btn1.style.backgroundColor="black";
    btn1.style.color="white";
}
btn2.onmouseover= function() {
    btn2.style.backgroundColor="black";
    btn2.style.color="white";
}
btn3.onmouseover= function() {
    btn3.style.backgroundColor="black";
    btn3.style.color="white";
}
btn4.onmouseover= function() {
    btn4.style.backgroundColor="black";
    btn4.style.color="white";
}
btn5.onmouseover= function() {
    btn5.style.backgroundColor="black";
    btn5.style.color="white";
}
btn6.onmouseover= function() {
    btn6.style.backgroundColor="black";
    btn6.style.color="white";
}

btnIncrease.onmouseleave= function() {
    btnIncrease.style.backgroundColor="";
    btnIncrease.style.color="black";
}
btnDecrease.onmouseleave= function() {
    btnDecrease.style.backgroundColor="";
    btnDecrease.style.color="black";
}
btn1.onmouseleave= function() {
    btn1.style.backgroundColor="";
    btn1.style.color="black";
}
btn2.onmouseleave= function() {
    btn2.style.backgroundColor="";
    btn2.style.color="black";
}
btn3.onmouseleave= function() {
    btn3.style.backgroundColor="";
    btn3.style.color="black";
}
btn4.onmouseleave= function() {
    btn4.style.backgroundColor="";
    btn4.style.color="black";
}
btn5.onmouseleave= function() {
    btn5.style.backgroundColor="";
    btn5.style.color="black";
}
btn6.onmouseleave= function() {
    btn6.style.backgroundColor="";
    btn6.style.color="black";
}

btnIncrease.addEventListener('click', function() {
    increaseFontSize += 5;
    if(increaseFontSize > 45) {
        alert("Maximum Size Reached.\nFont Size: "+increaseFontSize+"\nClick \"Font -\" to Decrease the size now");
    } else {
        increasingText.style.fontSize= increaseFontSize + 'px';
    }
});

btnDecrease.addEventListener('click', function() {
    increaseFontSize -= 5;
    if(increaseFontSize <= 15) {
        alert("Minimum font size is 15 px. \nCurrent Size is: "+increaseFontSize+"\nClick \"Font +\" to Increase the size now");
    } else {
        increasingText.style.fontSize = increaseFontSize +'px';
    }
});


var currentImg = 0;
var imgs = document.querySelectorAll('.slider img');
let dots = document.querySelectorAll('.dot');
var interval = 3000;

// Second banner
var secondEventTitle = 'Hi! *Freshmen* Orientation Day';

// Third banner
var thirdEventDate = new Date('2023-02-01'); // pull this from database
var thirdEventDateString = thirdEventDate.toLocaleDateString('en-us', { year: 'numeric', month: 'short', day: 'numeric' });
var days = calculateDays(new Date(), thirdEventDate) || 0;
const countdownText = days > 0 ? `${days} days left` : 'Live Now!';

var secondImageUrl = `/CSS.webp`;
var thirdImageUrl = `/JavaScript.png`;

document.getElementById('img-2').src = secondImageUrl;
document.getElementById('img-3').src = thirdImageUrl;

var timer = setInterval(changeSlide, interval);

function changeSlide(n) {
  for (var i = 0; i < imgs.length; i++) {
    imgs[i].style.opacity = 0;
    dots[i].className = dots[i].className.replace(' active', '');
  }

  currentImg = (currentImg + 1) % imgs.length;

  if (n != undefined) {
    clearInterval(timer);
    timer = setInterval(changeSlide, interval);
    currentImg = n;
  }

  imgs[currentImg].style.opacity = 1;
  dots[currentImg].className += ' active';
}

function calculateDays(today, eventDate) {
  const difference = eventDate.getTime() - today.getTime();

  return Math.ceil(difference / (1000 * 3600 * 24)); // convert to days
}

inputBox.addEventListener('input', function(e) {
    CurrntInputText= e.target.value;
});

btn1.addEventListener('click', function() {
    if(CurrntInputText === '' || CurrntInputText === undefined || CurrntInputText === null) {
        alert("Please enter a value. Empty String cannot be processed");
        
    } else {
        var newLi= document.createElement('li');
        var textNode= document.createTextNode("List Item "+(list.childElementCount) + ": " +CurrntInputText);
        var firstChild= list.firstChild;
        newLi.appendChild(textNode);
        newLi.id="listitem";
        list.insertBefore(newLi, firstChild);
        alert("Item Added Successfully to the First of the List");
        inputBox.value='';
        CurrntInputText='';
    }
});

btn2.addEventListener('click', function() {
    if(CurrntInputText === '' || CurrntInputText === undefined || CurrntInputText === null) {
        alert("Please enter a value. Empty String cannot be processed");
        
    } else {
        var newLi= document.createElement('li');
        var textNode= document.createTextNode("List Item "+(list.childElementCount) + ": " +CurrntInputText);
        newLi.appendChild(textNode);
        newLi.id="listitem";
        list.appendChild(newLi);
        alert("Item Added Successfully to the Last of the List");
        inputBox.value='';
        CurrntInputText='';
    }
});

btn3.addEventListener('click', function() {
    var firstChild= list.firstChild;
    list.removeChild(firstChild);
    var itemNum= list.childElementCount;
    alert("First List Item Remove Successfully\n"+itemNum+" Items Remaining");
});

btn4.addEventListener('click', function() {
    list.removeChild(list.lastElementChild);
    var itemNum= list.childElementCount;
    alert("Last List Item Remove Successfully\n"+itemNum+" Items Remaining");
});

btn5.addEventListener('click', function () {
    if(CurrntInputText === '' || CurrntInputText === undefined || CurrntInputText === null) {
        alert("Please enter a value. Empty String cannot be processed");
    } else {
        var firstChild= list.firstChild;
        var newLi= document.createElement('li');
        var textNode= document.createTextNode("List Item "+(list.childElementCount) + ": " +CurrntInputText);
        newLi.appendChild(textNode);
        newLi.id="listitem";
        list.replaceChild(newLi, firstChild);
        alert("First Child Update Successfully");
        inputBox.value='';
        CurrntInputText='';
    }
});

btn6.addEventListener('click', function () {
    if(CurrntInputText === '' || CurrntInputText === undefined || CurrntInputText === null) {
        alert("Please enter a value. Empty String cannot be processed");
    } else {
        var lastChild= list.lastChild;
        var newLi= document.createElement('li');
        var textNode= document.createTextNode("List Item "+(list.childElementCount) + ": " +CurrntInputText);
        newLi.appendChild(textNode);
        newLi.id="listitem";
        list.replaceChild(newLi, lastChild);
        alert("Last Child Update Successfully");
        inputBox.value='';
        CurrntInputText='';
    }
});